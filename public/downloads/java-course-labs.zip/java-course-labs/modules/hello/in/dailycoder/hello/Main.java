package in.dailycoder.hello;

public class Main {
    public static void main(String[] args) { System.out.println("Hello from a named module"); }
}
